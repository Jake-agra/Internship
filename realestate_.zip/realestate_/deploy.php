<?php
/**
 * Real Estate Website - Deployment Verification & Health Check
 * Run this script to verify your installation is working correctly
 */

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Real Estate Website - System Health Check</title>
    <link rel="stylesheet" href="bootstrap-5.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { background: #f8fafc; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .status-pass { color: #10b981; }
        .status-fail { color: #ef4444; }
        .status-warn { color: #f59e0b; }
        .check-item { 
            padding: 0.75rem; 
            margin: 0.5rem 0; 
            border-radius: 8px; 
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-5">
                <h1 class="mb-3"><i class="fas fa-home me-2"></i>Real Estate Website</h1>
                <h2 class="h4 text-muted">System Health Check & Deployment Verification</h2>
                <p class="text-muted">Verifying your installation is working correctly...</p>
            </div>

            <?php
            $checks = [];
            $overall_status = true;

            // PHP Version Check
            $php_version = PHP_VERSION;
            $php_ok = version_compare($php_version, '7.4.0', '>=');
            $checks[] = [
                'name' => 'PHP Version',
                'status' => $php_ok,
                'message' => "PHP $php_version " . ($php_ok ? '(✓ Compatible)' : '(✗ Requires 7.4+)'),
                'critical' => true
            ];
            if (!$php_ok) $overall_status = false;

            // Required PHP Extensions
            $extensions = ['mysqli', 'gd', 'json', 'fileinfo', 'session'];
            foreach ($extensions as $ext) {
                $loaded = extension_loaded($ext);
                $checks[] = [
                    'name' => "PHP Extension: $ext",
                    'status' => $loaded,
                    'message' => $loaded ? 'Loaded' : 'Missing',
                    'critical' => true
                ];
                if (!$loaded) $overall_status = false;
            }

            // Database Connection
            $db_status = false;
            $db_message = '';
            try {
                include('./Database/connection.php');
                if (isset($conn) && $conn->ping()) {
                    $db_status = true;
                    $db_message = 'Connected successfully';
                    
                    // Check if tables exist
                    $tables = ['users', 'properties', 'property_types', 'locations', 'prices'];
                    foreach ($tables as $table) {
                        $result = $conn->query("SHOW TABLES LIKE '$table'");
                        $table_exists = $result && $result->num_rows > 0;
                        $checks[] = [
                            'name' => "Database Table: $table",
                            'status' => $table_exists,
                            'message' => $table_exists ? 'Exists' : 'Missing',
                            'critical' => true
                        ];
                        if (!$table_exists) $overall_status = false;
                    }
                } else {
                    $db_message = 'Connection failed';
                }
            } catch (Exception $e) {
                $db_message = 'Error: ' . $e->getMessage();
            }
            
            $checks[] = [
                'name' => 'Database Connection',
                'status' => $db_status,
                'message' => $db_message,
                'critical' => true
            ];
            if (!$db_status) $overall_status = false;

            // File Permissions
            $upload_dir = 'uploads/';
            $upload_writable = is_writable($upload_dir) || (!is_dir($upload_dir) && mkdir($upload_dir, 0755, true) && is_writable($upload_dir));
            $checks[] = [
                'name' => 'Upload Directory',
                'status' => $upload_writable,
                'message' => $upload_writable ? "Writable ($upload_dir)" : "Not writable ($upload_dir)",
                'critical' => false
            ];

            // Key Files Check
            $key_files = [
                'index.php' => 'Homepage',
                'property.php' => 'Property Listings',
                'property_details.php' => 'Property Details',
                'login.php' => 'User Login',
                'admin/dashboard.php' => 'Admin Dashboard',
                'css/main.css' => 'Main Stylesheet',
                'Database/connection.php' => 'Database Configuration'
            ];

            foreach ($key_files as $file => $name) {
                $exists = file_exists($file);
                $checks[] = [
                    'name' => $name,
                    'status' => $exists,
                    'message' => $exists ? "Found ($file)" : "Missing ($file)",
                    'critical' => true
                ];
                if (!$exists) $overall_status = false;
            }

            // Admin User Check
            $admin_exists = false;
            if ($db_status && isset($conn)) {
                $admin_check = $conn->query("SELECT COUNT(*) as count FROM users u JOIN roles r ON u.role_id = r.id WHERE r.role_name = 'admin'");
                if ($admin_check) {
                    $admin_count = $admin_check->fetch_assoc()['count'];
                    $admin_exists = $admin_count > 0;
                }
            }
            
            $checks[] = [
                'name' => 'Admin User',
                'status' => $admin_exists,
                'message' => $admin_exists ? 'Admin user found' : 'No admin user found',
                'critical' => false
            ];

            // Bootstrap & Assets
            $bootstrap_exists = file_exists('bootstrap-5.3.7-dist/css/bootstrap.min.css');
            $checks[] = [
                'name' => 'Bootstrap Framework',
                'status' => $bootstrap_exists,
                'message' => $bootstrap_exists ? 'Bootstrap 5 found' : 'Bootstrap missing',
                'critical' => false
            ];

            // Display Results
            ?>

            <div class="row">
                <div class="col-12">
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header <?= $overall_status ? 'bg-success text-white' : 'bg-danger text-white' ?>">
                            <h5 class="mb-0">
                                <i class="fas fa-<?= $overall_status ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
                                Overall Status: <?= $overall_status ? 'PASSED' : 'FAILED' ?>
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if ($overall_status): ?>
                                <p class="text-success mb-0">
                                    <i class="fas fa-thumbs-up me-2"></i>
                                    Congratulations! Your Real Estate website is properly configured and ready to use.
                                </p>
                            <?php else: ?>
                                <p class="text-danger mb-0">
                                    <i class="fas fa-exclamation-circle me-2"></i>
                                    Some critical issues need to be resolved before your website will work properly.
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <h4 class="mb-3">Detailed Check Results</h4>
                    <?php foreach ($checks as $check): ?>
                        <div class="check-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= htmlspecialchars($check['name']) ?></strong>
                                <?php if ($check['critical'] && !$check['status']): ?>
                                    <span class="badge bg-danger ms-2">Critical</span>
                                <?php endif; ?>
                            </div>
                            <div class="text-end">
                                <span class="<?= $check['status'] ? 'status-pass' : 'status-fail' ?>">
                                    <i class="fas fa-<?= $check['status'] ? 'check' : 'times' ?> me-1"></i>
                                    <?= htmlspecialchars($check['message']) ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <?php if ($overall_status): ?>
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card border-success">
                            <div class="card-header bg-light">
                                <h5 class="text-success mb-0"><i class="fas fa-rocket me-2"></i>Next Steps</h5>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <h6><i class="fas fa-home me-2"></i>Website Access</h6>
                                        <p class="mb-2"><a href="index.php" class="btn btn-primary btn-sm">Visit Homepage</a></p>
                                        <p class="mb-2"><a href="property.php" class="btn btn-outline-primary btn-sm">Property Listings</a></p>
                                    </div>
                                    <div class="col-md-6">
                                        <h6><i class="fas fa-user-shield me-2"></i>Admin Access</h6>
                                        <p class="mb-2"><a href="admin/dashboard.php" class="btn btn-success btn-sm">Admin Dashboard</a></p>
                                        <p class="text-muted small">Default: admin@realestate.com / password</p>
                                    </div>
                                </div>
                                <hr>
                                <h6><i class="fas fa-list-check me-2"></i>Recommended Actions</h6>
                                <ul class="mb-0">
                                    <li>Change the default admin password</li>
                                    <li>Add your property listings</li>
                                    <li>Customize colors and branding</li>
                                    <li>Test all functionality</li>
                                    <li>Set up regular backups</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card border-danger">
                            <div class="card-header bg-light">
                                <h5 class="text-danger mb-0"><i class="fas fa-wrench me-2"></i>Troubleshooting</h5>
                            </div>
                            <div class="card-body">
                                <h6>Common Solutions:</h6>
                                <ul>
                                    <li><strong>Database Issues:</strong> Check connection settings in Database/connection.php</li>
                                    <li><strong>Missing Files:</strong> Ensure all files were uploaded correctly</li>
                                    <li><strong>PHP Extensions:</strong> Enable missing extensions in php.ini</li>
                                    <li><strong>Permissions:</strong> Set uploads/ directory to 755 or 777</li>
                                    <li><strong>Database Schema:</strong> Import Database/realestate_complete.sql</li>
                                </ul>
                                <div class="alert alert-info mt-3">
                                    <i class="fas fa-info-circle me-2"></i>
                                    For detailed setup instructions, see <strong>SETUP_GUIDE.md</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <h6><i class="fas fa-info-circle me-2"></i>System Information</h6>
                            <div class="row g-3 small">
                                <div class="col-md-3">
                                    <strong>PHP Version:</strong><br><?= PHP_VERSION ?>
                                </div>
                                <div class="col-md-3">
                                    <strong>Server:</strong><br><?= $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown' ?>
                                </div>
                                <div class="col-md-3">
                                    <strong>Document Root:</strong><br><?= $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown' ?>
                                </div>
                                <div class="col-md-3">
                                    <strong>Check Time:</strong><br><?= date('Y-m-d H:i:s') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center mt-4">
                <button onclick="location.reload()" class="btn btn-outline-secondary">
                    <i class="fas fa-redo me-2"></i>Re-run Checks
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>