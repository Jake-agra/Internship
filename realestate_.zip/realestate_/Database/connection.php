<?php
/**
 * Enhanced Database Connection Handler
 * Secure, robust connection with multiple fallback methods
 */

// Define debug mode constant if not already defined
if (!defined('DEBUG_MODE')) {
    define('DEBUG_MODE', false); // Set to true for development
}

// Error reporting for development
if (defined('DEBUG_MODE') && DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

// Database configuration class
class DatabaseConfig {
    private static $config = [
        'host' => 'localhost',
    'database' => 'realestate',
        'username' => 'root',
        'password' => '',
        'port' => 3306,
        'charset' => 'utf8mb4',
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    ];
    
    public static function get($key) {
        // Check for environment variables first
        $env_key = 'DB_' . strtoupper($key);
        if (isset($_ENV[$env_key])) {
            return $_ENV[$env_key];
        }
        
        return self::$config[$key] ?? null;
    }
}

// Database connection class
class DatabaseConnection {
    private static $instance = null;
    private $connection = null;
    private $mysqli = null;
    
    private function __construct() {
        $this->connect();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function connect() {
        $host = DatabaseConfig::get('host');
        $database = DatabaseConfig::get('database');
        $username = DatabaseConfig::get('username');
        $password = DatabaseConfig::get('password');
        $port = DatabaseConfig::get('port');
        $charset = DatabaseConfig::get('charset');
        
        // Try multiple connection methods
        $attempts = [
            "mysql:host={$host};port={$port};dbname={$database};charset={$charset}",
            "mysql:host=127.0.0.1;port={$port};dbname={$database};charset={$charset}",
            "mysql:host=localhost;dbname={$database};charset={$charset}",
            "mysql:host={$host};dbname={$database};charset={$charset}" // Fallback without port
        ];
        
        $lastException = null;
        
        foreach ($attempts as $dsn) {
            try {
                $this->connection = new PDO($dsn, $username, $password, DatabaseConfig::get('options'));
                
                // Test the connection
                $this->connection->query('SELECT 1');
                
                // Connection successful
                break;
            } catch (PDOException $e) {
                $lastException = $e;
                continue;
            }
        }
        
        if (!$this->connection) {
            $this->handleConnectionError($lastException);
        }
    }
    
    private function handleConnectionError($exception) {
        $errorMessage = $exception ? $exception->getMessage() : 'Unknown database error';
        
        // Log the error (in production)
        error_log("Database connection failed: " . $errorMessage);
        
        // Show user-friendly error page
        if (defined('DEBUG_MODE') && DEBUG_MODE) {
            echo $this->getDebugErrorPage($errorMessage);
            exit; // unreachable: script intentionally terminated after error output
        } else {
            echo $this->getProductionErrorPage();
            exit; // unreachable: script intentionally terminated after error output
        }
    }
    
    private function getDebugErrorPage($error) {
        return "<div style='background: #f8d7da; color: #721c24; padding: 20px; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px; font-family: Arial, sans-serif;'>
            <h3>⚠️ Database Connection Error</h3>
            <p><strong>Could not connect to MySQL database.</strong></p>
            <p><strong>Error:</strong> {$error}</p>
            <div style='margin-top: 15px; padding: 10px; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 3px;'>
                <p><strong>Quick Fix Steps:</strong></p>
                <ol>
                    <li>Start XAMPP/WAMP/MAMP Control Panel</li>
                    <li>Start Apache and MySQL services</li>
                    <li>Check database name: 'realestate'</li>
                    <li>Verify username and password</li>
                    <li>Refresh this page</li>
                </ol>
            </div>
        </div>";
    }
    
    private function getProductionErrorPage() {
        return "<div style='text-align: center; padding: 50px; font-family: Arial, sans-serif;'>
            <h1>Service Temporarily Unavailable</h1>
            <p>We're experiencing technical difficulties. Please try again later.</p>
        </div>";
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function getPDO() {
        return $this->connection;
    }
    
    // For backward compatibility with mysqli code
    public function getMysqli() {
        if (!isset($this->mysqli)) {
            $host = DatabaseConfig::get('host');
            $database = DatabaseConfig::get('database');
            $username = DatabaseConfig::get('username');
            $password = DatabaseConfig::get('password');
            $port = DatabaseConfig::get('port');
            
            try {
                $this->mysqli = new mysqli($host, $username, $password, $database, $port);
                $this->mysqli->set_charset(DatabaseConfig::get('charset'));
                
                if ($this->mysqli->connect_error) {
                    throw new Exception("MySQLi connection failed: " . $this->mysqli->connect_error);
                }
            } catch (Exception $e) {
                $this->handleConnectionError($e);
            }
        }
        
        return $this->mysqli;
    }
}

// Global database connections for backward compatibility
try {
    $db = DatabaseConnection::getInstance();
    $pdo = $db->getPDO();
    $conn = $db->getMysqli(); // For existing mysqli code
    
    // Enable error reporting for mysqli
    if ($conn) {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    }
    
} catch (Exception $e) {
    error_log("Database initialization failed: " . $e->getMessage());
    
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        echo $this->getDebugErrorPage($e->getMessage());
        exit;
    } else {
        die("Database connection failed. Please try again later.");
    }
}

// Database helper functions
function executeQuery($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("Query execution failed: " . $e->getMessage());
        throw $e;
    }
}

function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetch();
}

function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetchAll();
}

function getLastInsertId() {
    global $pdo;
    return $pdo->lastInsertId();
}

?>