<?php
require_once('connection.php');

// Force error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if database exists, if not create it
$conn->query("CREATE DATABASE IF NOT EXISTS realestate");
$conn->select_db("realestate");

// Create agencies table if it doesn't exist
$createTable = "CREATE TABLE IF NOT EXISTS `agencies` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `agency_name` varchar(200) NOT NULL,
    `license_number` varchar(100) DEFAULT NULL,
    `description` text,
    `logo_url` varchar(500) DEFAULT NULL,
    `website` varchar(500) DEFAULT NULL,
    `email` varchar(150) NOT NULL,
    `phone` varchar(20) DEFAULT NULL,
    `address` text,
    `is_active` tinyint(1) DEFAULT 1,
    `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_agency_name` (`agency_name`),
    KEY `idx_agency_status` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($createTable)) {
    echo "Agencies table is ready.\n\n";
} else {
    die("Error creating table: " . $conn->error);
}

// Check existing agencies
echo "=== Existing Agencies ===\n";
$query = "SELECT agency_name, license_number, email FROM agencies";
$result = $conn->query($query);

if ($result) {
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Agency: {$row['agency_name']}\n";
            echo "License: {$row['license_number']}\n";
            echo "Email: {$row['email']}\n";
            echo "------------------------\n";
        }
    } else {
        echo "No agencies found in database.\n";
    }
} else {
    echo "Error checking agencies: " . $conn->error . "\n";
}

// Insert new agencies with unique names
$newAgencies = [
    [
        'name' => 'Elite Properties International',
        'license' => 'EPI12345',
        'description' => 'Leading luxury real estate agency',
        'email' => 'contact@eliteproperties.com',
        'phone' => '+1-555-0123'
    ],
    [
        'name' => 'Global Realty Partners',
        'license' => 'GRP67890',
        'description' => 'Your trusted local real estate partner',
        'email' => 'info@globalrealty.com',
        'phone' => '+1-555-0124'
    ]
];

echo "\n=== Adding New Agencies ===\n";

foreach ($newAgencies as $agency) {
    $stmt = $conn->prepare("INSERT INTO agencies (agency_name, license_number, description, email, phone) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", 
        $agency['name'],
        $agency['license'],
        $agency['description'],
        $agency['email'],
        $agency['phone']
    );
    
    if ($stmt->execute()) {
        echo "Successfully added agency: {$agency['name']}\n";
    } else {
        echo "Error adding agency {$agency['name']}: " . $stmt->error . "\n";
    }
    $stmt->close();
}

// Check updated agencies list
echo "\n=== Updated Agencies List ===\n";
$result = $conn->query("SELECT agency_name, license_number, email FROM agencies");
if ($result) {
    while($row = $result->fetch_assoc()) {
        echo "Agency: {$row['agency_name']}\n";
        echo "License: {$row['license_number']}\n";
        echo "Email: {$row['email']}\n";
        echo "------------------------\n";
    }
}

$conn->close();
?>