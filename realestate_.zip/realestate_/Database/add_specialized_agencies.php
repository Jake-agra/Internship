<?php
$host = 'localhost';
$user = 'root';
$pass = '';

try {
    $conn = new mysqli($host, $user, $pass, 'realestate');
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // New agencies with different specialties
    $newAgencies = [
        [
            'name' => 'Luxury Estates International',
            'license' => 'LEI78901',
            'description' => 'Specializing in luxury properties and high-end real estate investments',
            'email' => 'info@luxuryestates.com',
            'phone' => '+1-555-0125'
        ],
        [
            'name' => 'Commercial Property Experts',
            'license' => 'CPE34567',
            'description' => 'Commercial real estate specialists focusing on office spaces and retail properties',
            'email' => 'contact@commercialexperts.com',
            'phone' => '+1-555-0126'
        ],
        [
            'name' => 'Modern Living Solutions',
            'license' => 'MLS89012',
            'description' => 'Contemporary residential properties and smart homes',
            'email' => 'info@modernliving.com',
            'phone' => '+1-555-0127'
        ],
        [
            'name' => 'Investment Property Group',
            'license' => 'IPG45678',
            'description' => 'Specializing in investment properties and property portfolio management',
            'email' => 'invest@ipgroup.com',
            'phone' => '+1-555-0128'
        ]
    ];

    echo "=== Adding New Specialized Agencies ===\n";
    
    foreach ($newAgencies as $agency) {
        $stmt = $conn->prepare("INSERT INTO agencies (agency_name, license_number, description, email, phone) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", 
            $agency['name'],
            $agency['license'],
            $agency['description'],
            $agency['email'],
            $agency['phone']
        );
        
        if ($stmt->execute()) {
            echo "Successfully added: {$agency['name']}\n";
        } else {
            if ($conn->errno == 1062) { // Duplicate entry error
                echo "Note: {$agency['name']} already exists\n";
            } else {
                echo "Error adding {$agency['name']}: " . $stmt->error . "\n";
            }
        }
        $stmt->close();
    }
    
    // Display all agencies
    echo "\n=== Current Agency Directory ===\n";
    $result = $conn->query("SELECT agency_name, license_number, description, email FROM agencies ORDER BY agency_name");
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "\nAGENCY: {$row['agency_name']}\n";
            echo "License: {$row['license_number']}\n";
            echo "Focus: {$row['description']}\n";
            echo "Contact: {$row['email']}\n";
            echo "----------------------------------------\n";
        }
        
        echo "\nTotal Agencies: " . $result->num_rows . "\n";
    }
    
    $conn->close();
    
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>