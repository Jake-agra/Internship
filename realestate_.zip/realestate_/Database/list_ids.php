<?php
require_once('connection.php');

// List agencies
echo "=== Agencies ===\n";
$res = $conn->query("SELECT id, agency_name FROM agencies ORDER BY id");
while ($row = $res->fetch_assoc()) {
    echo "ID: {$row['id']} | Name: {$row['agency_name']}\n";
}

// List users
echo "\n=== Users ===\n";
$res = $conn->query("SELECT id, first_name, last_name, email FROM users ORDER BY id");
while ($row = $res->fetch_assoc()) {
    echo "ID: {$row['id']} | Name: {$row['first_name']} {$row['last_name']} | Email: {$row['email']}\n";
}

$conn->close();
