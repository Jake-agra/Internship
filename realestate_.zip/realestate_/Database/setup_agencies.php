<?php
$host = 'localhost';
$user = 'root';
$pass = '';

try {
    // Connect without database first
    $conn = new mysqli($host, $user, $pass);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    echo "Connected successfully\n";
    
    // Create database if not exists
    if ($conn->query("CREATE DATABASE IF NOT EXISTS realestate")) {
        echo "Database 'realestate' is ready\n";
    } else {
        die("Error creating database: " . $conn->error);
    }
    
    // Select the database
    if ($conn->select_db("realestate")) {
        echo "Selected database 'realestate'\n";
    } else {
        die("Error selecting database: " . $conn->error);
    }
    
    // Create agencies table
    $createTable = "CREATE TABLE IF NOT EXISTS `agencies` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `agency_name` varchar(200) NOT NULL,
        `license_number` varchar(100) DEFAULT NULL,
        `description` text,
        `logo_url` varchar(500) DEFAULT NULL,
        `website` varchar(500) DEFAULT NULL,
        `email` varchar(150) NOT NULL,
        `phone` varchar(20) DEFAULT NULL,
        `address` text,
        `is_active` tinyint(1) DEFAULT 1,
        `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_agency_name` (`agency_name`),
        KEY `idx_agency_status` (`is_active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($conn->query($createTable)) {
        echo "Agencies table is ready\n";
    } else {
        die("Error creating table: " . $conn->error);
    }
    
    // Check existing agencies
    echo "\n=== Existing Agencies ===\n";
    $result = $conn->query("SELECT agency_name, license_number, email FROM agencies");
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "Agency: {$row['agency_name']}\n";
            echo "License: {$row['license_number']}\n";
            echo "Email: {$row['email']}\n";
            echo "------------------------\n";
        }
    } else {
        echo "No agencies found. Adding sample agencies...\n\n";
        
        // Insert new agencies
        $insertAgencies = "INSERT INTO agencies (agency_name, license_number, description, email, phone) VALUES
            ('Elite Properties International', 'EPI12345', 'Leading luxury real estate agency', 'contact@eliteproperties.com', '+1-555-0123'),
            ('Global Realty Partners', 'GRP67890', 'Your trusted local real estate partner', 'info@globalrealty.com', '+1-555-0124')";
        
        if ($conn->query($insertAgencies)) {
            echo "Sample agencies added successfully!\n";
        } else {
            echo "Error adding agencies: " . $conn->error . "\n";
        }
    }
    
    $conn->close();
    
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>