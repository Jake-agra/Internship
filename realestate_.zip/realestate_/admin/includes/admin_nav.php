<?php
// Admin navigation component
if (!isset($_SESSION['user_id']) || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}
?>

<!-- Sidebar -->
<nav class="sidebar">
    <div class="sidebar-header">
        <a href="dashboard.php" class="sidebar-brand">
            <i class="fas fa-home me-2"></i>Real Estate Admin
        </a>
    </div>
    
    <div class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="properties.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'properties.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i>
                    Properties
                    <span class="badge bg-primary ms-auto"><?= $stats['total_properties'] ?? '0'; ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a href="add_property.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'add_property.php' ? 'active' : ''; ?>">
                    <i class="fas fa-plus"></i>
                    Add Property
                </a>
            </li>
            <li class="nav-item">
                <a href="users.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i>
                    Users
                    <span class="badge bg-warning ms-auto"><?= $stats['total_users'] ?? '0'; ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a href="inquiries.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'inquiries.php' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i>
                    Inquiries
                    <?php if (isset($stats['pending_inquiries']) && $stats['pending_inquiries'] > 0): ?>
                        <span class="badge bg-danger ms-auto"><?= $stats['pending_inquiries']; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a href="reports.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i>
                    Reports
                </a>
            </li>
            <li class="nav-item">
                <a href="image_manager.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'image_manager.php' ? 'active' : ''; ?>">
                    <i class="fas fa-images"></i>
                    Image Manager
                </a>
            </li>
            <li class="nav-item">
                <a href="settings.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i>
                    Settings
                </a>
            </li>
            <li class="nav-item mt-3 pt-3 border-top">
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-external-link-alt"></i>
                    View Website
                </a>
            </li>
            <li class="nav-item">
                <a href="../logout.php" class="nav-link text-danger">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
</nav>