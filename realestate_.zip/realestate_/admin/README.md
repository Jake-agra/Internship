# Real Estate Admin Panel - User Management Setup Guide

## Overview
This document provides setup instructions for the user management system in the Real Estate Admin Panel. The system includes user listing, role management, activation/deactivation, and secure user operations.

## Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- Bootstrap 5.3.x
- FontAwesome 6.5.x

## Database Setup
1. Ensure the database is set up using the `realestate_complete.sql` file in the Database folder
2. The following tables are required:
   - users (user account information)
   - roles (user role definitions)
   - properties (for property ownership)
   - inquiries (for user inquiries)

## Security Features
The user management system includes several security measures:
- CSRF Protection for all forms
- Input validation and sanitization
- Secure session handling
- Security headers (XSS Protection, Content-Type Options, etc.)
- Prepared statements for database queries
- Role-based access control

## File Structure
```
admin/
├── users.php          # Main user management interface
├── dashboard.php      # Admin dashboard
├── includes/         
│   └── admin_nav.php  # Admin navigation
includes/
├── route.php         # Routing and authentication
├── security.php      # Security functions
└── enhanced_auth.php # Authentication handlers
```

## Configuration Steps
1. Database Configuration
   - Update `Database/connection.php` with your database credentials
   - Ensure proper database permissions

2. Security Configuration
   - Set secure session parameters in php.ini or .htaccess
   - Configure HTTPS for secure communication
   - Set appropriate file permissions

3. User Roles Setup
   - Default roles: admin, agent, user
   - Customize roles through the database

## Usage Instructions
1. User Management
   - List/Search Users: Filter by role, status, or search terms
   - User Actions: Activate/Deactivate, Change Role, Delete
   - Pagination: 20 users per page

2. Security Best Practices
   - Always validate CSRF tokens
   - Sanitize all user inputs
   - Maintain secure session handling
   - Regular security audits

## Error Handling
- Input validation errors are displayed to users
- CSRF validation failures are logged
- Database errors are handled gracefully

## Maintenance
- Regularly update dependencies
- Monitor error logs
- Backup user data
- Review security settings

## Support
For technical support or questions:
- Check documentation in code comments
- Contact system administrator
- Review error logs in your server's log directory